var x;

var offset = 10;

function setup() {
  createCanvas(400, 400);

x = width/2;
}


let value = 0;

// Move the mouse across the canvas to create the shapes
function draw() {
  fill(value);
  background(204);
  fill(255,29,0,100);
  rect(200, mouseY, 100, mouseX);
  fill(107,23,255,100);
  ellipse(150, mouseY, 100, mouseX);
  fill(23,255,67,100);
  rect(0, mouseY, 100, mouseX);
  fill(255,150,0,100);
  ellipse(350, mouseY, 100, mouseX);
  if (keyIsPressed) {
    fill(255,0,0,100);
    rect(160,200,100,400);
    
    if (mouseX > x) {

		x += 0.5;
		offset = -10;

	}

	if (mouseX < x) {

		x -= 0.5;
		offset = 10;

	}

	// Draw arrow left or right depending on "offset" value

	line(x, 0, x, height);

	line (mouseX, mouseY, mouseX + offset, mouseY - 10);

	line (mouseX, mouseY, mouseX + offset, mouseY + 10);
	
	line (mouseX, mouseY, mouseX + offset * 3, mouseY);

}

  }


function mouseClicked() {
  if (value === 0) {
    value = 255;
  } else {
    value = 0;
  }
}