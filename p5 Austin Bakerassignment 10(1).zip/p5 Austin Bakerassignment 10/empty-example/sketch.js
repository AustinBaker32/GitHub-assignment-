let vid;
function setup() {
  createCanvas(600,600);
  background(125);

  vid = createVideo(
    ['assets/Cubs.mp4' , 'assets/Cubs.ogv' , 'assets/Cubs.webm'],
    vidLoad
  );

  vid.size(400, 400);
}
function draw() {
	textSize(55);
	fill(255,0,0,100);
	text('Go Cubs Go' , 200, 200);
	fill(9,1,235,92);
	text('Fly the W' , 235, 275);
}

// This function is called when the video loads
function vidLoad() {
  vid.loop();
  vid.volume(0);
}